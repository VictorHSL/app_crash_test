export abstract class BaseModel extends Object {
    id?: string
    created: number;
    creatorId: string;

    constructor(){
        super();
        
        this.created = new Date().getTime();
        this.creatorId = "";
    }
}