import { BaseModel } from './base.model';
// import { IsNotEmpty } from 'class-validator';

export class User extends BaseModel {

    // @IsNotEmpty({
    //     message: 'Name is empty.'
    // })
    public name: string;

    // @IsNotEmpty({
    //     message: 'Email is empty.'
    // })
    public email: string;

    public photo?: string;

    public active: boolean;

    defaultSignature: string;

    language: string;

    constructor(){
        super();

        this.name = '';
        this.email = '';
        this.photo = '';
        this.active = false;
        this.defaultSignature = '';
        this.language = 'pt-br';
    }

    getFirstUser(){
        let user = new User();
        user.id = 'first';
        return user;
    }
}
